﻿using OpenHardwareMonitor.Hardware;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Threading;

namespace Diagnostic_tool
{
    class CpuTempSensor : GenericSensorValue<string>
    {
        private static Queue<string> cores = new Queue<string>();
        private static int m_syncPoint;
        public override System.Timers.Timer timer { get; set; }
        public override Queue<object> SensorValues { get; set; }
        public override Queue<DateTime> SensorTimeStamp { get; set; }

        public CpuTempSensor()
        {
            ID = 3;
            SensorName = this.GetType().FullName.Split('.').Last().ToLower();
            SensorValues = new Queue<object>();
            SensorTimeStamp = new Queue<DateTime>();
            StartTimer();
        }
        public override void StartTimer()
        {
            TimeSpan timeSpan = new TimeSpan(0, 5, 0);
            double interval = timeSpan.TotalMilliseconds;
            timer = new System.Timers.Timer(interval);
            timer.Elapsed += OnTimerSetValue;
            timer.AutoReset = true;
            timer.Start();
        }

        public override void OnTimerSetValue(object sender, System.Timers.ElapsedEventArgs args)
        {
            if (!QueueIsLocked)
            {
                
                if (0 == System.Threading.Interlocked.Exchange(ref m_syncPoint, 1))
                {
                    SensorValue =  GetCpuTempratures("");
                    System.Threading.Interlocked.Exchange(ref m_syncPoint, 0);
                }

                if (0 == System.Threading.Interlocked.Exchange(ref m_syncPoint, 1))
                {
                    SensorValues.Enqueue(SensorValue);
                    SensorTimeStamp.Enqueue(DateTime.Now);

                    ValuesCollected += 1;
                    System.Threading.Interlocked.Exchange(ref m_syncPoint, 0);
                }
            }
        }

        private string GetCpuTempratures(string value)
        {
            UpdateVisitor updateVisitor = new UpdateVisitor();
            Computer computer = new Computer();
            computer.Open();
            computer.CPUEnabled = true;

            computer.Accept(updateVisitor);
            for (int i = 0; i < computer.Hardware.Length; i++)
            {
                if (computer.Hardware[i].HardwareType == HardwareType.CPU)
                {
                    for (int j = 0; j < computer.Hardware[i].Sensors.Length; j++)
                    {
                        if (computer.Hardware[i].Sensors[j].SensorType == SensorType.Temperature)
                        {
                            string name = computer.Hardware[i].Sensors[j].Name;
                            string cpu_coreName = name.Substring(9, 2);
                            string cpu_coreValue = computer.Hardware[i].Sensors[j].Value.ToString();
                            cores.Enqueue($"{cpu_coreName}.{cpu_coreValue}");
                        }
                            SensorValue = (computer.Hardware[i].Sensors[j].Name + ":" + computer.Hardware[i].Sensors[j].Value.ToString() + "\r");
                    }
                }
            }
            computer.Close();
            
            int cpu_core_ammount = cores.Count;
            for (int i = 0; i < cpu_core_ammount; i++)
            {
                string val = cores.Dequeue();
                value += $"{val}";
            }

            return value;
        }
    }

    class UpdateVisitor : IVisitor
    {
        public void VisitComputer(IComputer computer)
        {
            computer.Traverse(this);
        }
        public void VisitHardware(IHardware hardware)
        {
            hardware.Update();
            foreach (IHardware subHardware in hardware.SubHardware) subHardware.Accept(this);
        }
        public void VisitSensor(ISensor sensor) { }
        public void VisitParameter(IParameter parameter) { }
    }


}
