﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Diagnostic_tool
{
    class Log
    {
        public int Pk_sensor_id { get; set; }
        public string Sensor_name { get; set; }
        public string Product_key { get; set; }
        public DateTime Log_timestamp { get; set; }
        public string Log_value { get; set; }

        private static string row;
        public static string Row
        {
            get { return row; }
            set { row = value; }
        }
        private static Stack<Log> rows = new Stack<Log>();
        public static Stack<Log> Rows
        {
            get { return rows; }
            set { rows = value; }
        }

        //private static string Path;

        //internal static void CreateLogFile()
        //{
        //    DateTime dt = DateTime.Now;
        //    Path = $"C:\\Users\\Public\\Documents\\{dt.Year}{dt.Month}{dt.Day}{dt.Hour}.txt";
        //    // This text is added only once to the file.
        //    if (!File.Exists(Path))
        //    {
        //        // Create a file to write to.
        //        using (StreamWriter sw = File.CreateText(Path))
        //        {
        //            sw.WriteLine("\\\\sensorid,productkey_or_macaddress,datetime,sensorvalue");
        //            sw.WriteLine(Row);
        //        }
        //    }
        //    else
        //    {
        //        // This text is always added, making the file longer over time
        //        // if it is not deleted.
        //        using (StreamWriter sw = File.AppendText(Path))
        //        {
        //            sw.WriteLine(Row);
        //        }
        //    }

        //}

        //internal static void ReadLogFiles()
        //{
        //    Path = @"C:\Users\Public\Documents\";
        //    FileInfo[] datafolder = new System.IO.DirectoryInfo(Path).GetFiles().Where(f => (f.Name.EndsWith(".txt"))).ToArray();

        //    foreach (var file in datafolder)
        //    {
        //        //Use this Stack To Check if Name exist in DB
        //        //FileNames.Push(file.Name);
        //        try
        //        {   // Open the text file using a stream reader.
        //            using (StreamReader sr = new StreamReader(Path + file.Name))
        //            {
        //                // Read the stream to a string, and write the string to the console.
        //                String line = sr.ReadToEnd();
        //                Console.WriteLine(line);
        //            }
        //        }
        //        catch (Exception e)
        //        {
        //            Console.WriteLine("The file could not be read:");
        //            Console.WriteLine(e.Message);
        //        }
        //    }
        //}
    }
}
