﻿using Diagnostic_tool.Http;
using Diagnostic_tool.Properties;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Media;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;

namespace Diagnostic_tool
{
    class Monitor
    {
        //Make binding to timespan from client to manipulate the logTime

        private DataHandler dataHandler = new DataHandler();

        private DispatcherTimer hartbeat = new DispatcherTimer();
        public DispatcherTimer Hartbeat
        {
            get { return hartbeat; }
            set { hartbeat = value; }
        }
        private static double postInterval {get; set;}

        private string productkey { get; set; }

        private static int LogCounter;
        public static int SensorCounts { get; private set; }
        
        public Monitor()
        {
            PlayerDevice pd = new PlayerDevice();
            try
            {
                productkey = pd.ReadProduct();
            }
            catch (Exception)
            {
                //get pc mac_address
                try
                {
                    string mac_address = pd.GetMACAddress();
                }
                catch (Exception ex)
                {
                    DataHandler.CreateExeption(ex);
                }
            }

            Hartbeat.Interval = new TimeSpan(0, 5, 0);
            postInterval = 3600000/ Hartbeat.Interval.TotalMilliseconds;
            Hartbeat.Tick += new EventHandler(Observe);
        }

        internal void Start()
        {
            SensorFactory.CreateSensors();
            SensorFactory.sensorsCollected = true;
            SensorCounts = SensorFactory.SensorCollection.Count;
            LogCounter = 0;
            Hartbeat.Start();
        }
        private void Observe(object sender, EventArgs e)
        {
            while (Sensor.ValuesCollected < SensorCounts)
            {
                Thread.Sleep(100);
            }
            if (GuiManager.ObserveIsReady)
            {
                if (Sensor.ValuesCollected >= SensorCounts)
                {
                    Sensor.QueueIsLocked = true;
                }
                while (Sensor.QueueIsLocked)
                {
                    CollectDiagnosticData();
                    Sensor.ValuesCollected = 0;
                    Sensor.QueueIsLocked = false;
                    LogCounter++;
                    //Write Log.Rows to ..//..//diagnostic_data
                    dataHandler.CreateLogFile();
                }
                //Task t001 = dataHandler.ReadAndPostFiles();
                if (LogCounter == postInterval)
                {
                    LogCounter = 0;
                    Task t001 = dataHandler.ReadAndPostFiles();

                    //Only for testing
                    {
                        //SystemSounds.Beep.Play();
                        //MessageBox.Show("Logging is done");
                        ////Hartbeat.Stop();
                    }
                }
            }
        }

        private void CollectDiagnosticData()
        {
            for (int i = 0; i < SensorCounts; i++)
            {
                Sensor sensor = SensorFactory.SensorCollection[i];
                int valueCounts = sensor.SensorValues.Count;

                for (int j = 0; j < valueCounts; j++)
                {
                    Log.Rows.Push(new Log
                    {
                        Pk_sensor_id = sensor.ID,
                        Sensor_name = sensor.SensorName,
                        Product_key = productkey,
                        Log_timestamp = sensor.SensorTimeStamp.Dequeue(),
                        Log_value = string.Format(new CultureInfo("en-US"), "{0}", sensor.SensorValues.Dequeue())
                    });
                }
            }
        }
    }
}