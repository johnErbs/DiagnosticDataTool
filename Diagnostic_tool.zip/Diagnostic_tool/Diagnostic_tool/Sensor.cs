﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Diagnostic_tool
{
    abstract class Sensor
    {
        private int id;

        public int ID
        {
            get { return id; }
            set { id = value; }
        }
        private string sensorName;

        public string SensorName
        {
            get { return sensorName; }
            set { sensorName = value; }
        }


        public static bool QueueIsLocked { get; set; }
        public static int ValuesCollected { get; set; }
        public abstract Queue<object> SensorValues { get; set; }
        public abstract Queue<DateTime> SensorTimeStamp { get; set; }
        public abstract object GetSensor();
    }
}
