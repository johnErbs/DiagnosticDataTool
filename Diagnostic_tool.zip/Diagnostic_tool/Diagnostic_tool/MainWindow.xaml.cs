﻿using Diagnostic_tool.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Diagnostic_tool
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Monitor monitor = new Monitor();
        DateTime dt = new DateTime();
        static BackgroundWorker guiWorker = new BackgroundWorker();
        static bool isRunning;
        GuiManager gui = new GuiManager();

        public MainWindow()
        {
            InitializeComponent();
            this.main_controls.DataContext = (gui);
            dt = DateTime.Now;
            gui.Label_CopyR = $"(C) {dt.Year} MediaConnect";
            isRunning = true;
            guiWorker.DoWork += ObserveDataChanges;
            guiWorker.RunWorkerAsync();
            monitor.Start();
        }

        private void ObserveDataChanges(object sender, EventArgs args)
        {
            while (isRunning)
            {
                string collectorTxt = "Indsamler Sensorer";
                gui.Label_sensorCounts = collectorTxt;
                gui.Label_logTransfer = collectorTxt;
                gui.Label_SystemError = collectorTxt;
                if (SensorFactory.sensorsCollected)
                {
                    collectorTxt = "Starter Sensorer";
                    gui.Label_sensorCounts = collectorTxt;
                    gui.Label_logTransfer = collectorTxt;
                    gui.Label_SystemError = collectorTxt;
                    Thread.Sleep(3000);
                    break;
                }
            }

            if(Monitor.SensorCounts!=0)
                GuiManager.ObserveIsReady = true;

            gui.Label_logTransfer = $"Diagnostiseret data overført til lokal logfil: {0}";
            gui.Label_sensorCounts = $"Systemet opstartede {Monitor.SensorCounts} sensore til diagnostisering af afspillerenhed";
            gui.Label_SystemError = $"Systemfejl: {DataHandler.SystemErrors}";

            while (isRunning)
            {
                if (DataHandler.DiagnosticDataCount == Monitor.SensorCounts)
                {
                    DataHandler.DiagnosticDataCount = 0;
                    gui.LocalFileCounts++;
                    gui.Label_logTransfer = $"Diagnostiseret data_rækker overført til lokal log: {gui.LocalFileCounts * Monitor.SensorCounts}";
                    gui.Label_SystemError = $"Systemfejl: {DataHandler.SystemErrors}\n{DataHandler.ErrMessage}";
                }
                if (!isRunning)
                    break;
            }
        }
    }
}
