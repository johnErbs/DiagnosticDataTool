﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Threading;

namespace Diagnostic_tool
{
    class StatusSensor : GenericSensorValue<byte>
    {
        public static bool response { get; set; }
        private static int m_syncPoint = 0;
        public override System.Timers.Timer timer { get; set; }
        public override Queue<object> SensorValues { get; set ; }
        public override Queue<DateTime> SensorTimeStamp { get; set; }

        public StatusSensor()
        {
            response = true;
            if (!response)
                SensorValue = 0;
            else
            {
                ID = 1;
                SensorName = this.GetType().FullName.Split('.').Last().ToLower();
                SensorValues = new Queue<object>();
                SensorTimeStamp = new Queue<DateTime>();
                StartTimer();
            }

        }
        public override void StartTimer()
        {
            TimeSpan timeSpan = new TimeSpan(0, 5, 0);
            double interval = timeSpan.TotalMilliseconds;
            timer = new System.Timers.Timer(interval);
            timer.Elapsed += OnTimerSetValue;
            timer.AutoReset = true;
            timer.Start();
        }
        public override void OnTimerSetValue(object sender, System.Timers.ElapsedEventArgs args)
        {
            if (response && !QueueIsLocked)
            {
                if (0 == System.Threading.Interlocked.Exchange(ref m_syncPoint, 1))
                {
                    SensorValue = 1;
                    System.Threading.Interlocked.Exchange(ref m_syncPoint, 0);
                }
                if (0 == System.Threading.Interlocked.Exchange(ref m_syncPoint, 1))
                {
                    SensorValues.Enqueue(SensorValue);
                    SensorTimeStamp.Enqueue(DateTime.Now);
                    ValuesCollected += 1;
                    System.Threading.Interlocked.Exchange(ref m_syncPoint, 0);
                }
            }
        }
    }
}
