﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Threading;

namespace Diagnostic_tool
{
    abstract class GenericSensorValue<SensorValueType> : Sensor, ISensorVal
    {
        public SensorValueType SensorValue { get; set; }
        
        public abstract System.Timers.Timer timer { get; set; }
        

        public override object GetSensor()
        {
            return SensorValue;
        }

        public abstract void OnTimerSetValue(object sender, System.Timers.ElapsedEventArgs args);
        public abstract void StartTimer();
        
    }
}
