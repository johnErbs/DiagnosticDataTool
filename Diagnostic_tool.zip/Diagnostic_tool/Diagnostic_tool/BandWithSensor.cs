﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Threading;

namespace Diagnostic_tool
{
    class BandWithSensor : GenericSensorValue<double>
    {
        private static int m_syncPoint;
        public override System.Timers.Timer timer { get; set; }
        public override Queue<object> SensorValues { get; set; }
        public override Queue<DateTime> SensorTimeStamp { get; set; }

        public BandWithSensor()
        {
            ID = 2;
            SensorName = this.GetType().FullName.Split('.').Last().ToLower();
            SensorValues = new Queue<object>();
            SensorTimeStamp = new Queue<DateTime>();
            StartTimer();
        }
        public override void StartTimer()
        {
            TimeSpan timeSpan = new TimeSpan(0, 5, 0);
            double interval = timeSpan.TotalMilliseconds;
            timer = new System.Timers.Timer(interval);
            timer.Elapsed += OnTimerSetValue;
            timer.AutoReset = true;
            timer.Start();
        }
        public override void OnTimerSetValue(object sender, System.Timers.ElapsedEventArgs args)
        {
            if (!QueueIsLocked)
            {
                if (0 == System.Threading.Interlocked.Exchange(ref m_syncPoint, 1))
                {
                    SensorValue = TestDownloadSpeed();
                    System.Threading.Interlocked.Exchange(ref m_syncPoint, 0);
                }

                if (0 == System.Threading.Interlocked.Exchange(ref m_syncPoint, 1))
                {
                    SensorValues.Enqueue(SensorValue);
                    SensorTimeStamp.Enqueue(DateTime.Now);
                    ValuesCollected += 1;
                    System.Threading.Interlocked.Exchange(ref m_syncPoint, 0);
                }
            }
        }

        public double TestDownloadSpeed()
        {
            double[] speeds = new double[5];
            WebClient client = new WebClient();

            for (int i = 0; i < 5; i++)
            {
                int fileSize = 100; //Size of File in KB.
                DateTime startTime = DateTime.Now;
                client.DownloadFile("https://drive.google.com/open?id=1xX_bIWNIEZd29A8JQidGpcgeAP2riqDa", "test100k.db");
                DateTime endTime = DateTime.Now;
                speeds[i] = Math.Round((fileSize / (endTime - startTime).TotalSeconds));
            }

            //downloadSpeed = string.Format($"Download Speed: {speeds.Average()}KB/s");
            double downloadSpeed = speeds.Average();
            return downloadSpeed;
        }
    }
}
