﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Net.Http.Headers;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;

namespace Diagnostic_tool.Http
{
    class DataHandler 
    {
        private static string filePath { get; set; }
        private Queue<Log> logs = new Queue<Log>();
        private static bool ignoreData;
        protected static bool Success, FileIsTransfered, accessKeyCollected;
        public static int DiagnosticDataCount { get; set; }
        public static int SystemErrors { get; set; }
        public static string ErrMessage { get; set; }
        private HttpResponseMessage response { get; set; }

        internal static void CreateExeption(Exception ex)
        {
            SystemErrors++;
            string exName = ex.GetType().FullName;
        }

        internal void CreateLogFile()
        {
            DateTime dt = DateTime.Now;
            filePath = $@"..\..\diagnostic_data\{dt.Year}{dt.Month}{dt.Day}{dt.Hour}.txt";
            // This text is added only once to the file.
            if (!File.Exists(filePath))
            {
                // Create a file to write to.
                using (StreamWriter sw = File.CreateText(filePath))
                {
                    sw.WriteLine("\\\\sensor_id,sensor_type,productkey_or_macaddress,datetime,sensorvalue");

                    int rows = Log.Rows.Count;
                    for (int i = 0; i < rows; i++)
                    {
                        Log log = Log.Rows.Pop();
                        Log.Row = $"{log.Pk_sensor_id},{log.Sensor_name},{log.Product_key},{log.Log_timestamp},{log.Log_value}";
                        sw.WriteLine(Log.Row);

                        //GUI info used in MainWindow
                        DiagnosticDataCount++;
                    }
                }
            }
            else
            {
                // This text is always added, making the file longer over time
                using (StreamWriter sw = File.AppendText(filePath))
                {
                    int rows = Log.Rows.Count;
                    for (int i = 0; i < rows; i++)
                    {
                        Log log = Log.Rows.Pop();
                        Log.Row = $"{log.Pk_sensor_id},{log.Sensor_name},{log.Product_key},{log.Log_timestamp},{log.Log_value}";
                        sw.WriteLine(Log.Row);

                        //GUI info used in MainWindow
                        DiagnosticDataCount++;
                    }
                }
            }
        }


        internal async Task ReadAndPostFiles()
        {
            int sensorID = 0;
            string sensorName = "";
            string productKey = "";
            string sensorValue = "";
            DateTime logTimeStamp = new DateTime();
            //HttpResponseMessage response = new HttpResponseMessage(); ;
            //accessKeyCollected = false;

            //filePath = Environment.CurrentDirectory + "\\diagnostic_data";
            filePath = @"..\..\diagnostic_data\";
            FileInfo[] datafolder = new DirectoryInfo(filePath).GetFiles().Where(f => (f.Name.EndsWith(".txt"))).ToArray();


            for (int i = 0; i < datafolder.Length; i++)
            {
                FileInfo logFile = datafolder[i];
                try
                {   // Open the text file using a stream reader.
                    using (StreamReader reader = new StreamReader(filePath + logFile.Name))
                    {
                        // Read the stream to a string, and write the string to the console.
                        string line;
                        while ((line = await reader.ReadLineAsync()) != null)
                        {
                            if (line.Contains(@"\\"))
                                ignoreData = true;
                            else
                            {
                                ignoreData = false;
                            }

                            if (!ignoreData)
                            {
                                //line = await reader.ReadLineAsync();
                                string[] attributeValues = line.Split(',');
                                int valueCounts = 0;

                                foreach (string value in attributeValues)
                                {
                                    //We have 4 values that should be set before saving to queue;
                                    if (valueCounts > 5)
                                        valueCounts = 0;
                                    valueCounts++;

                                    switch (valueCounts)
                                    {
                                        case 1:
                                            sensorID = int.Parse(value);
                                            break;
                                        case 2:
                                            sensorName = value;
                                            break;
                                        case 3:
                                            productKey = value;
                                            break;
                                        case 4:
                                            logTimeStamp = Convert.ToDateTime(value);
                                            break;
                                        case 5:
                                            sensorValue = value;
                                            logs.Enqueue(new Log
                                            {
                                                Pk_sensor_id = sensorID,
                                                Sensor_name = sensorName,
                                                Product_key = productKey,
                                                Log_timestamp = logTimeStamp,
                                                Log_value = sensorValue
                                            });
                                            break;
                                    }
                                }
                            }
                        }
                    }

                    using (var client = new HttpClient())
                    {
                        int fileRows = logs.Count;
                        object[] logFileRows = new object[fileRows];
                        //log.AccesKey = accessKey;
                        dynamic log = new ExpandoObject();
                        for (int j = 0; j < fileRows; j++)
                        {
                            logFileRows[j] = logs.Dequeue();
                        }
                        log.File = logFileRows;
                        var myContent = JsonConvert.SerializeObject(log);
                        var buffer = Encoding.UTF8.GetBytes(myContent);
                        var byteContent = new ByteArrayContent(buffer);

                        client.BaseAddress = new Uri("http://localhost:51065");
                        client.DefaultRequestHeaders.Clear();
                        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Authorization", productKey);
                        byteContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                        response = await client.PostAsync("/api/DiagnosticData", byteContent);
                        response.EnsureSuccessStatusCode();
                        //Get response
                        if (response.IsSuccessStatusCode)
                        {
                            //Delete File
                            if (File.Exists(filePath + logFile.Name))
                            {
                                string _historicFilePath = @"..\..\historic_data\";
                                DateTime dt = DateTime.Now;

                                if (File.Exists(_historicFilePath + logFile.Name))
                                {
                                    File.Copy(filePath + logFile.Name, _historicFilePath + +dt.Minute + dt.Second + logFile.Name);
                                }
                                else
                                {
                                    File.Copy(filePath + logFile.Name, _historicFilePath + logFile.Name);
                                }
                                File.Delete(filePath + logFile.Name);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    SystemErrors++;
                    ErrMessage = ex.Message;
                    string exName = ex.GetType().FullName;

                    if (exName == "System.Net.Http.HttpRequestException")
                    {
                        HttpRequestException ex503 =  (HttpRequestException)ex;
                        if (response == null)
                        {
                            HttpResponseMessage rawResponse = new HttpResponseMessage(HttpStatusCode.ServiceUnavailable);
                            string systemData = 
                                ($"Server Ude af drift!\nKontakt udbyder MediaConnect, for udbedring af fejlen!\n{ex503.Message}\n{rawResponse}\n");
                            LogSystemError(systemData, rawResponse);

                            break;
                        }
                        else if(response.StatusCode == HttpStatusCode.Unauthorized)
                        {
                            HttpRequestException ex401 = (HttpRequestException) ex;
                            DateTime dt = DateTime.Now;
                            string systemData = 
                                $"{ex401.ToString()}\nProduktnøgle: {productKey} er invalid!\nKontakt udbyder MediaConnect aps for udbedring af fejlen.";
                            LogSystemError(systemData, response);
                            break;
                        }
                    }
                }
            }
        }

        private void LogSystemError(string systemData, HttpResponseMessage rawResponse)
        {
            DateTime dt = DateTime.Now;
            if(rawResponse!=null)
                filePath = $@"..\..\system_data\{rawResponse.StatusCode}{dt.Year}{dt.Month}{dt.Day}{dt.Hour}.txt";
            else
            {

            }

            // This text is added only once to the file.
            if (!File.Exists(filePath))
            {
                // Create a file to write to.
                using (StreamWriter sw = File.CreateText(filePath))
                {
                    sw.WriteLine($"{dt}\n{systemData}");
                }
            }
            else
            {
                // This text is always added, making the file longer over time
                using (StreamWriter sw = File.AppendText(filePath))
                {
                    sw.WriteLine($"{dt}\n{systemData}");
                }
            }
        }
        



                


    }
}
       
