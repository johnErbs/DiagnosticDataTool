﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Diagnostic_tool
{
    class GuiManager : INotifyPropertyChanged
    {
        private int localFileCounts;
        public int LocalFileCounts
        {
            get
            {
                return localFileCounts;
            }
            set
            {
                localFileCounts = value;
                NotifyPropertyChanged();
            }
        }
        private string label_logTransfer;

        public string Label_logTransfer
        {
            get { return label_logTransfer; }
            set
            {
                label_logTransfer = value;
                NotifyPropertyChanged();
            }
        }
        private string label_CopyR;
        public string Label_CopyR
        {
            get {return label_CopyR; }
            internal set
            {
                label_CopyR = value;
                NotifyPropertyChanged();
            }
        }

        private string label_sensorCounts;
        public string Label_sensorCounts
        {
            get { return label_sensorCounts; }
            internal set
            {
                label_sensorCounts = value;
                NotifyPropertyChanged();
            }
        }

        public static bool ObserveIsReady { get; internal set; }
        private string label_SystemError;
        public string Label_SystemError
        {
            get {return label_SystemError; }
            internal set
            {
                label_SystemError = value;
                NotifyPropertyChanged();
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void NotifyPropertyChanged([CallerMemberName] String propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}