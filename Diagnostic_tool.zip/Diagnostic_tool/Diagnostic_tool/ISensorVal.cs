﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Diagnostic_tool
{
    interface ISensorVal
    {
        void OnTimerSetValue(object sender, System.Timers.ElapsedEventArgs args);
        void StartTimer();
    }
}
