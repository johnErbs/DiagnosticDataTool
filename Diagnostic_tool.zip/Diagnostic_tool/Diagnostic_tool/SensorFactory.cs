﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Diagnostic_tool
{
    abstract class SensorFactory
    {
        private static Type[] types { get; set; }
        private static Type type { get; set; }
        public static bool sensorsCollected, counterSet;
        private static List<Sensor> sensorCollection = new List<Sensor>();
        public static List<Sensor> SensorCollection
        {
            get { return sensorCollection; }
            set { sensorCollection = value; }
        }


        public static void CreateSensors()
        {
            IEnumerable<Type> subclasses;
            subclasses = GetSensorChildren();


            foreach (Type t in subclasses)
            {
                if(t.Name!= "GenericSensorValue`1")
                {
                    try
                    {
                        type = Type.GetType($"Diagnostic_tool.{t.Name}", true);
                        //create an instance Sensortypes 
                        SensorCollection.Add((Sensor)Activator.CreateInstance(t));
                    }
                    catch (Exception ex)
                    {
                        //Log ex to system_data

                    }
                }
            }
            
            Array.Clear(types, 0, types.Length);
        }

        private static IEnumerable<Type> GetSensorChildren()
        {
            Type parentType = typeof(Sensor);
            Assembly assembly = Assembly.GetExecutingAssembly();
            types = assembly.GetTypes();
            IEnumerable<Type> subclasses = types.Where(t => t.IsSubclassOf(parentType));
            
            return subclasses;
        }
    }
}
