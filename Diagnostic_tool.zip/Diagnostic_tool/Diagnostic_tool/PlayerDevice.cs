﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Management;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Schema;

namespace Diagnostic_tool
{
    class PlayerDevice
    {
        private string productKey;
        public string ProductKey
        {
            get { return productKey; }
            set { productKey = value; }
        }

        private Dictionary<string, string> deviceSettings = new Dictionary<string, string>();
        public Dictionary<string, string> DeviceSettings
        {
            get { return deviceSettings; }
            set { deviceSettings = value; }
        }

        private string url;

        internal PlayerDevice()
        {
            url = @"C:\LiveConnectCDS\LiveConnectCDS\LiveConnectClient.settings";
        }

        internal string ReadProduct()
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(url);

            foreach(XmlNode node in doc.DocumentElement.ChildNodes)
            {
                var name = node.Attributes["key"].Value;
                var value = node.InnerText;
                DeviceSettings.Add(name, value);
                foreach (KeyValuePair<string, string> item in DeviceSettings)
                {
                    if (item.Key == "productkey")
                    {
                        return ProductKey = node.InnerText;
                    }
                }
            }
            if(ProductKey == null)
            {
                throw new System.ArgumentNullException();
            }

            return ProductKey;
        }

        internal string GetMACAddress()
        {
            ManagementObjectSearcher searcher = new ManagementObjectSearcher("SELECT * FROM Win32_NetworkAdapterConfiguration where IPEnabled=true");
            IEnumerable<ManagementObject> objects = searcher.Get().Cast<ManagementObject>();
            string mac = (from o in objects orderby o["IPConnectionMetric"] select o["MACAddress"].ToString()).FirstOrDefault();
            return mac;
        }
    }
}
