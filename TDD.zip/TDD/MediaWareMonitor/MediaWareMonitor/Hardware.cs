﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MediaWareMonitor
{
    class Hardware
    {
        public static bool Memory { get; set; }
        public static bool Cpu { get; set; }
        public static bool Tempprature { get; set; }
    }
}
