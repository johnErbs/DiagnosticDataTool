﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace data_access.entities
{
    public class Player_device
    {
        public int PD_id { get; set; }
        public string PD_name { get; set; }
        public string ProductKey { get; set; }
    }
}
