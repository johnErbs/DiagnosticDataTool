﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace data_access.entities
{
    public class DataLog
    {
        private int pk_sensor_id;
        public int Pk_sensor_id
        {
            get { return pk_sensor_id; }
            set { pk_sensor_id = value; }
        }
        private string sensor_name;

        public string Sensor_name
        {
            get { return sensor_name; }
            set { sensor_name = value; }
        }

        private string productKey;
        public string Product_key
        {
            get { return productKey; }
            set { productKey = value; }
        }

        private DateTime log_timestamp = new DateTime();
        public DateTime Log_timestamp
        {
            get { return log_timestamp; }
            set { log_timestamp = value; }
        }
        private int dtYear;
        public int DtYear
        {
            get { return dtYear; }
            set { dtYear = value; }
        }
        private int dtMonth;
        public int DtMonth
        {
            get { return dtMonth; }
            set { dtMonth = value; }
        }
        private int dtDay;
        public int DtDay
        {
            get { return dtDay; }
            set { dtDay = value; }
        }
        private TimeSpan time = new TimeSpan();
        public TimeSpan Time
        {
            get { return time; }
            set { time = value; }
        }

        private string log_value;
        public string Log_value
        {
            get { return log_value; }
            set { log_value = value; }
        }

        private int fk_sensor_id;
        public int Fk_sensor_id
        {
            get { return fk_sensor_id; }
            set { fk_sensor_id = value; }
        }

        private int fk_pd_id;
        public int Fk_pd_id
        {
            get { return fk_pd_id; }
            set { fk_pd_id = value; }
        }

        private static string row;
        public static string Row
        {
            get { return row; }
            set { row = value; }
        }
    }
}
