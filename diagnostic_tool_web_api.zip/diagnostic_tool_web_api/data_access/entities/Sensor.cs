﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace data_access.entities
{
    internal class Sensor
    {
        private int sensorID;
        public int SensorID
        {
            get { return sensorID; }
            set { sensorID = value; }
        }

        private string sensorName;
        public string SensorName
        {
            get { return sensorName; }
            set { sensorName = value; }
        }
    }
}
