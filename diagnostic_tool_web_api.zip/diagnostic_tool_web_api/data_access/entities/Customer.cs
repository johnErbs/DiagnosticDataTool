﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace data_access.entities
{
    public class Customer
    {
        public int Pk_cust_id { get; set; }
        public string Cust_name { get; set; }
    }
}
