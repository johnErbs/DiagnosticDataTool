﻿using data_access.entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace data_access.data_access_layer
{
    /// <summary>
    /// this class act as an incapsulation of the DataAccesLayer  
    /// and provides access to the DAL from base type: API constroller.
    /// </summary>

    public class DataContextLayer
    {
        protected string _customer_data { get; set; }
        protected string _device_data { get; set; }
        protected dynamic _data { get; set; }
        protected DataContextLayer(string customer, string device, dynamic data)
        {
            _customer_data = customer;
            _device_data = device;
            _data = data;
        }

        // get resource from DAL 
        protected dynamic GetSetData(int query_id)
        {
            dynamic data = new object();

            switch (query_id)
            {
                case 1:
                    data = DAL.GetLog(_customer_data, _device_data, _data);
                    break;
                case 2:
                    data = DAL.GetCustomers();
                    break;
                case 3:

                    data = DAL.GetDevices(_customer_data);
                    break;
                case 4:
                    DAL.CreateLog(_data);
                    return null;
                case 5:
                    data = DAL.ReadProdKeyComparison(_data);
                    break;
                case 6:
                    data = DAL.GetSensorDetails(_data);
                    break;
                case 7:
                    data = DAL.GetProductKey(_device_data);
                    break;
            }

            return data;
        }

        // Call from DiagnosticDataController
        public static List<DataLog> ReadDataLog(List<DataLog> dataLog, bool authentificated, Type baseType, string customer, string device, int days, DateTime date_to)
        {
            if (authentificated && baseType.Name == "ApiController")
            {
                dynamic[] days_dateTo = new dynamic[2];
                days_dateTo[0] = days;
                days_dateTo[1] = date_to;

                DataContextLayer DCL = new DataContextLayer(customer,device, days_dateTo);
                dataLog = DCL.GetSetData(1);
            }
            else
            {
                dataLog = null;
            }

            return dataLog;
        }
        // Call from CustomerDataController
        public static List<Customer> ReadCustomerData(List<Customer> customers, bool authentificated, Type baseType)
        {
            if (authentificated && baseType.Name == "ApiController")
            {
                DataContextLayer DCL = new DataContextLayer("","", "");
                customers = DCL.GetSetData(2);
            }
            else
            {
                customers = null;
            }

            return customers;
        }

        // Call from PlayerDeviceController
        public static List<Player_device> ReadPlayerDevice(List<Player_device> deviceCollection, bool authentificated, Type baseType, string customer)
        {
            if (authentificated && baseType.Name == "ApiController")
            {
                DataContextLayer DCL = new DataContextLayer(customer,"", "");
                deviceCollection = DCL.GetSetData(3);
            }
            else
            {
                deviceCollection = null;
            }

            return deviceCollection;
        }

        // Call from DiagnosticDataController
        public static void CreateDataLog(DataLog log, Type baseType)
        {
            if(baseType.Name == "ApiController")
            {
                DataContextLayer DCL = new DataContextLayer("", "", log);
                DCL.GetSetData(4);
            }
            //DAL.CreateLog(log);
        }

        // Call from PlayerDeviceSecurityController
        public static string ReadDataDeviceKey(string productKey)
        {
            DataContextLayer DCL = new DataContextLayer("", "", productKey);
            productKey = DCL.GetSetData(5);
            return productKey;
            //productKey = DAL.ReadProdKeyComparison(productKey);
        }

        // Call from SensorDetailsController
        public static List<DataLog> ReadSensorDataLog(List<DataLog> data_log,int Fk_sensor_id, string product_key, bool authentificated, Type baseType, string days, string date_to)
        {
            if (authentificated && baseType.Name == "ApiController")
            {
                dynamic[] id_key = new dynamic[4];
                id_key[0]= Fk_sensor_id;
                id_key[1] = product_key;
                id_key[2] = days;
                id_key[3] = date_to;

                DataContextLayer DCL = new DataContextLayer("", "", id_key);
                data_log = DCL.GetSetData(6);
            }
            return data_log;
        }

        // Call from DiagnosticDataController
        public static string GetProductkey(bool authentificated, Type baseType, string device)
        {
            string productKey = "";
            if (authentificated && baseType.Name == "ApiController")
            {
                DataContextLayer DCL = new DataContextLayer("", device, "");
                productKey = DCL.GetSetData(7);
            }
            return productKey;
        }

    }
}
