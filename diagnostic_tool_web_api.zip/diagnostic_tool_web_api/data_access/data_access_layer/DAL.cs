﻿using data_access.entities;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Threading;

namespace data_access.data_access_layer
{
    internal class DAL
    {
        // Class is internal and cannot be accessed from outside this project Scope.

        private static MySqlConnection connection = null;
        // Open Connection
        private static void Open()
        {
            connection = new MySqlConnection(ConfigurationManager.ConnectionStrings["MySQLConnection"].ConnectionString);

            try
            {
                connection.Open();
            }
            catch (MySqlException mysql_ex)
            {
                throw mysql_ex;
            }
        }
        //Close Connection
        private static void Close()
        {
            try
            {
                connection.Close();
            }
            catch (MySqlException mysql_ex)
            {
                throw mysql_ex;
            }
        }
        // Read PKey for basic security
        internal static string ReadProdKeyComparison(string productkey)
        {
            try
            {
                Open();
                MySqlCommand cmd = new MySqlCommand("SELECT * FROM player_device WHERE product_key = @productKey", connection);
                cmd.Parameters.Add(CreateParam("@productKey", productkey, MySqlDbType.VarChar));

                MySqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    string TempKey = reader.GetString(1);

                    if (productkey == TempKey)
                    {
                        return productkey;
                    }
                }
                else
                {
                    return productkey = null;
                }
                Close();
            }
            catch (MySqlException mysql_ex)
            {
                throw mysql_ex;
            }
            
            return productkey;
        }
        // Insert data from player device
        internal static void CreateLog(DataLog log)
        {
            log.Product_key = Base64Encode(log.Product_key);
            try
            {
                Open();
                MySqlCommand cmd_read_sensor = new MySqlCommand("SELECT * FROM sensor WHERE sensor_type = @sensorName", connection);
                cmd_read_sensor.Parameters.Add(CreateParam("@sensorName", log.Sensor_name, MySqlDbType.VarChar));
                MySqlDataReader reader = cmd_read_sensor.ExecuteReader();
                if (!reader.Read())
                {
                    Close();
                    Open();
                    MySqlCommand cmd_create_sensor = new MySqlCommand("INSERT INTO sensor (pk_sensor_id, sensor_type) VALUES(@sensorID, @sensorName)", connection);
                    cmd_create_sensor.Parameters.Add(CreateParam("@sensorID", log.Pk_sensor_id, MySqlDbType.Int32));
                    cmd_create_sensor.Parameters.Add(CreateParam("@sensorName", log.Sensor_name, MySqlDbType.VarChar));
                    cmd_create_sensor.ExecuteNonQuery();
                }
                Close();

                Open();
                MySqlCommand cmd_get_fk = new MySqlCommand("SELECT * FROM player_device WHERE product_key = @productKey", connection);
                cmd_get_fk.Parameters.Add(CreateParam("@productKey", log.Product_key, MySqlDbType.VarChar));
                reader = cmd_get_fk.ExecuteReader();

                if (reader.Read())
                {
                    log.Fk_pd_id = reader.GetInt32(0);
                }
                Close();

                Open();
                log.Fk_sensor_id = log.Pk_sensor_id;
                MySqlCommand cmd = new MySqlCommand
                ("INSERT INTO data_Log(log_timestamp, log_value, fk_sensor_id, fk_pd_id) VALUES(@timeStamp, @value, @fk_sensorID, @fk_pd_ID)", connection);
                cmd.Parameters.Add(CreateParam("timeStamp", log.Log_timestamp, MySqlDbType.DateTime));
                cmd.Parameters.Add(CreateParam("value", log.Log_value, MySqlDbType.VarChar));
                cmd.Parameters.Add(CreateParam("fk_sensorID", log.Fk_sensor_id, MySqlDbType.Int32));
                cmd.Parameters.Add(CreateParam("fk_pd_ID", log.Fk_pd_id, MySqlDbType.Int32));
                cmd.ExecuteNonQuery();
                Close();
            }
            catch (MySqlException mysql_ex)
            {
                throw mysql_ex;
            }
        }

        // - Get resources section bellow ->

        internal static List<Customer> GetCustomers()
        {
            List<Customer>  customers = new List<Customer>();
            bool custinfoAdded = false;
            try
            {
                Open();
                MySqlCommand cmd = new MySqlCommand("SELECT * FROM customer", connection);
                MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    if (!custinfoAdded)
                    {
                        custinfoAdded = true;
                        customers.Add(new Customer
                        {
                            Pk_cust_id = 0,
                            Cust_name = "Vælg Kunde"
                        });
                    }
                    customers.Add(new Customer
                    {
                        Pk_cust_id = reader.GetInt32(0),
                        Cust_name = reader.GetString(1)
                    });
                }
                Close();
            }
            catch (MySqlException mysql_ex)
            {

                throw mysql_ex;
            }
            return customers;
        }

        internal static dynamic GetDevices(string customer)
        {
            List<Player_device>  deviceCollection = new List<Player_device>();
            MySqlCommand cmd = null;
            MySqlDataReader reader = null;
            int pk_cust_id = 0;
            bool playerDeviceAdded = false;

            try
            {
                Open();
                cmd = new MySqlCommand("SELECT * FROM customer WHERE cust_name = @cust_name", connection);
                cmd.Parameters.Add(CreateParam("cust_name", customer, MySqlDbType.VarChar));
                reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    pk_cust_id = reader.GetInt32(0);
                }
                Close();

                Open();
                cmd = new MySqlCommand("SELECT * FROM player_device WHERE fk_cust_id = @pk_cust_id", connection);
                cmd.Parameters.Add(CreateParam("pk_cust_id", pk_cust_id, MySqlDbType.VarChar));
                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    if (!playerDeviceAdded)
                    {
                        playerDeviceAdded = true;
                        deviceCollection.Add(new Player_device
                        {
                            PD_name = "Vælg enhed",
                            ProductKey = ""
                        });
                    }
                    deviceCollection.Add(new Player_device
                    {
                        PD_name = reader.GetString(3),
                        ProductKey = reader.GetString(1)
                    });
                }
                Close();
            }
            catch (MySqlException mysql_ex)
            {
                throw mysql_ex;
            }
            return deviceCollection;
        }

        internal static List<DataLog> GetLog(string customer, string device, dynamic days_dateTo)
        {
            MySqlCommand cmd = null;
            MySqlDataReader reader = null;
            List<DataLog> data_log = new List<DataLog>();
            DateTime dt = DateTime.Now;
            if (days_dateTo[1] != new DateTime())
            {
                dt = days_dateTo[1];
            }

            int deviceID = 0;
            string productKey = "";

            try
            {
                Open();
                cmd = new MySqlCommand("SELECT * FROM player_device WHERE pd_name = @deviceName;", connection);
                cmd.Parameters.Add(CreateParam("deviceName", device, MySqlDbType.VarChar));
                reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    deviceID = reader.GetInt32(0);
                    productKey = reader.GetString(1);
                }
                Close();

                Open();
                cmd = new MySqlCommand(
                    "SELECT data_log.fk_sensor_id, sensor.sensor_type, player_device.product_key, data_log.log_timestamp, data_log.log_value " +
                    "FROM data_log INNER JOIN sensor, player_device " +
                    "WHERE data_log.fk_sensor_id = sensor.pk_sensor_id " +
                    "AND data_log.fk_pd_id = player_device.pk_pd_id " +
                    "AND data_log.fk_pd_id = @pk_pd_id " +
                    "AND log_timestamp >= @dtPast " +
                    "AND log_timestamp <= @dtNow", connection);

                cmd.Parameters.Add(CreateParam("pk_pd_id", deviceID, MySqlDbType.Int32));
                cmd.Parameters.Add(CreateParam("dtPast", dt.Date.AddDays(-days_dateTo[0]), MySqlDbType.DateTime));
                cmd.Parameters.Add(CreateParam("dtNow", dt.Date, MySqlDbType.DateTime));

                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    data_log.Add(new DataLog
                    {
                        Fk_sensor_id = reader.GetInt32(0),
                        Sensor_name = reader.GetString(1),
                        Product_key = reader.GetString(2),
                        Log_timestamp = reader.GetDateTime(3),
                        Log_value = reader.GetString(4)
                    });
                }

                Close();
            }
            catch (MySqlException mysql_ex)
            {
                throw mysql_ex;
            }
            
            return data_log;
        }

        internal static void CreateSensor(Sensor sensor)
        {
            try
            {
                Open();
                MySqlCommand cmd = new MySqlCommand("INSERT INTO sensor(pk_sensor_id, sensor_type) VALUES(@sensor_id, @sensor_type)", connection);
                cmd.Parameters.Add(CreateParam("sensor_id", sensor.SensorID, MySqlDbType.Int32));
                cmd.Parameters.Add(CreateParam("sensor_type", sensor.SensorName, MySqlDbType.VarChar));

                cmd.ExecuteNonQuery();
            }
            catch (MySqlException mysql_ex)
            {
                throw mysql_ex;
            }
            finally
            {
                Close();
            }
        }
        internal static List<DataLog> GetSensorDetails(dynamic data)
        {
            MySqlCommand cmd = null;
            MySqlDataReader reader = null;
            List<DataLog> data_log_collection = new List<DataLog>();
            DataLog data_log = new DataLog();
            data_log.Fk_sensor_id = data[0];
            data_log.Product_key = data[1];
            int days = int.Parse(data[2]);
            DateTime dt = Convert.ToDateTime(data[3]);

            try
            {
                //get id from player_device table
                Open();
                cmd = new MySqlCommand("SELECT * FROM player_device WHERE product_key = @Product_key", connection);
                cmd.Parameters.Add(CreateParam("product_key", data_log.Product_key, MySqlDbType.VarChar));

                reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    data_log.Fk_pd_id = reader.GetInt32(0);
                }
                Close();
                // get all data from data_log inner-join (data_log, player_device, sensor)
                Open();
                cmd = new MySqlCommand(
                    "SELECT " +
                    "data_log.fk_sensor_id, sensor.sensor_type, " +
                    "player_device.product_key, data_log.log_timestamp,data_log.log_value " +
                    "FROM data_log " +
                    "CROSS JOIN sensor, player_device " +
                    "WHERE data_log.fk_sensor_id = sensor.pk_sensor_id " +
                    "AND data_log.fk_sensor_id = @Fk_sensor_id " +
                    "AND data_log.fk_pd_id = player_device.pk_pd_id " +
                    "AND data_log.fk_pd_id = @Fk_pd_id " +
                    "AND log_timestamp >= @dtPast " +
                    "AND log_timestamp <= @dtNow", connection);

                cmd.Parameters.Add(CreateParam("Fk_sensor_id", data_log.Fk_sensor_id, MySqlDbType.UInt32));
                cmd.Parameters.Add(CreateParam("Fk_pd_id", data_log.Fk_pd_id, MySqlDbType.Int32));
                cmd.Parameters.Add(CreateParam("dtPast", dt.Date.AddDays(-days), MySqlDbType.DateTime));
                cmd.Parameters.Add(CreateParam("dtNow", dt.Date, MySqlDbType.DateTime));

                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    data_log.Log_timestamp = reader.GetDateTime(3);

                    data_log_collection.Add(new DataLog
                    {
                        Pk_sensor_id = reader.GetInt32(0),
                        Sensor_name = reader.GetString(1),
                        Product_key = reader.GetString(2),
                        DtYear = data_log.Log_timestamp.Year,
                        DtMonth = data_log.Log_timestamp.Month,
                        DtDay = data_log.Log_timestamp.Day,
                        Time = new TimeSpan(data_log.Log_timestamp.Hour, data_log.Log_timestamp.Minute, data_log.Log_timestamp.Second),
                        Log_value = reader.GetString(4)
                    });
                }
                Close();
            }
            catch (Exception)
            {
                throw;
            }

            return data_log_collection;
        }

        internal static dynamic GetProductKey(string device_data)
        {
            string productKey = "";
            try
            {
                Open();
                MySqlCommand cmd = new MySqlCommand("SELECT * FROM player_device WHERE pd_name = @deviceName;", connection);
                cmd.Parameters.Add(CreateParam("deviceName", device_data, MySqlDbType.VarChar));
                MySqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    productKey = reader.GetString(1);
                }
                Close();
            }
            catch (Exception)
            {

                throw;
            }
            return productKey;
        }
        // Create parameter values for Mysql-querry
        private static MySqlParameter CreateParam(string name, object value, MySqlDbType type)
        {
            MySqlParameter param = new MySqlParameter(name, type);
            param.Value = value;
            return param;
        }
        //unittest
        #region DAL unitTest001
        private static void UnitTestOn_static_shared_MySqlConnection()
        {
            ///<Sumary>
            //This unit test is used to test if there will be a conflict of using a shared static connection on the gathered DAL Class.
            //To use this test follow the steps bellow: 
            //  1.  set the minute of the "dt" variable forward in time.
            //  2.  Call this method right before the Open(); methodCall in one of the desired methods of this class.
            //  3.  Login with 2 differend users on 2 differend browsersessions.
            //  4.  Querry the same resource from both users which refers to the disired method of this class.
            //  5.  Await the result to see if there will be any conflict on connection.Open();
            ///<Sumary />

            DateTime dt = 
                new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, DateTime.Now.Hour, /*set this:*/ 58, 00);
            while (DateTime.Now < dt)
            {
                // Wait...
                Thread.Sleep(1000);
            }
        }
        #endregion
        // encodes to base 64
        #region DAL Base64Encode
        public static string Base64Encode(string key)
        {
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(key);
            return System.Convert.ToBase64String(plainTextBytes);
        }
        #endregion
    }
}
