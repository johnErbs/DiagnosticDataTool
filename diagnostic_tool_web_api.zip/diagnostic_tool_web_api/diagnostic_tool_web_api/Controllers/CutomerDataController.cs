﻿using data_access.data_access_layer;
using data_access.entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace diagnostic_tool_web_api.Controllers
{
    // this APIcontroller provides IEnumerable Customer resources

    public class CutomerDataController : ApiController
    {
        protected bool Authentificated { get; set; }

        List<Customer> data_log = new List<Customer>();

        [Authorize]
        public IEnumerable<Customer> Get()
        {
            if (User.Identity.IsAuthenticated)
                Authentificated = true;

            return (data_log = DataContextLayer.ReadCustomerData(data_log, Authentificated, this.GetType().BaseType));
        }
    }
}
