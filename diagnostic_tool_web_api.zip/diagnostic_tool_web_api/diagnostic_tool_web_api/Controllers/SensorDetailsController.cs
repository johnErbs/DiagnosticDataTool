﻿using data_access.data_access_layer;
using data_access.entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace diagnostic_tool_web_api.Controllers
{
    //this APIcontroller provides IEnumerable sensor resources

    public class SensorDetailsController : ApiController
    {
        protected bool Authentificated { get; set; }
        List<DataLog> data_log = new List<DataLog>();

        [Authorize]
        public IEnumerable<DataLog> Get(string Fk_sensor_id, string product_key, string days, string date_to)
        {
            if (User.Identity.IsAuthenticated)
                Authentificated = true;
            return (data_log = DataContextLayer.ReadSensorDataLog(data_log, Convert.ToInt32(Fk_sensor_id), product_key, Authentificated, this.GetType().BaseType, days, date_to));
        }
    }
}
