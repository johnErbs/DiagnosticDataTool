﻿using data_access.data_access_layer;
using data_access.entities;
using diagnostic_tool_web_api.Models;
using diagnostic_tool_web_api.Security.AuthModels;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace diagnostic_tool_web_api.Controllers
{
    public class DiagnosticDataController : ApiController
    {
        ///
        // this APIcontroller provides IEnumerable DataLog resources
        // gives access for the playerdevice to post logged data
        ///

        //Properties 
        protected string accessKey { get; set; }
        protected bool Authentificated { get; set; }
        protected string productKey { get; set; }

        List<DataLog> data_log = new List<DataLog>();

        [Authorize]
        public IEnumerable<DataLog> Get(string customer, string device, string days, string date_to)
        {
            if (User.Identity.IsAuthenticated)
                Authentificated = true;
           
            return (data_log = DataContextLayer.ReadDataLog(
                data_log, Authentificated, this.GetType().BaseType, customer, device, Convert.ToInt32(days), Convert.ToDateTime(date_to)));
        }

        [Authorize]
        [Route("api/DiagnosticData/getkey/{device}")]
        public string Get(string device)
        {
            if (User.Identity.IsAuthenticated)
                Authentificated = true;
            return (productKey = DataContextLayer.GetProductkey(Authentificated, this.GetType().BaseType, device));
        }

        [BasicAuthentification]
        public void Post(JObject jsonResult)
        {
            JToken t = jsonResult.Last.First();
            DataLog[] logArray = t.ToObject<DataLog[]>();

            //Post data to DB
            for (int i = 0; i < logArray.Length; i++)
            {
                DataContextLayer.CreateDataLog(logArray[i], this.GetType().BaseType);
            }
        }
    }
}

