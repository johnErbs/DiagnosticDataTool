﻿using data_access.data_access_layer;
using data_access.entities;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace diagnostic_tool_web_api.Controllers
{
    //this APIcontroller provides IEnumerable Playerdevice resources

    public class PlayerDeviceController : ApiController
    {
        protected bool Authentificated { get; set; }

        List<Player_device> deviceCollection = new List<Player_device>();

        [Authorize]
        public List<Player_device> Get(string customer)
        {
            if (User.Identity.IsAuthenticated)
                Authentificated = true;

            return (deviceCollection = DataContextLayer.ReadPlayerDevice(deviceCollection, Authentificated, this.GetType().BaseType, customer));
        }
    }
}
