﻿using data_access.data_access_layer;
using data_access.entities;
using diagnostic_tool_web_api.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace diagnostic_tool_web_api.Controllers
{
    public class HomeController : Controller
    {
        //MainView
        public ViewResult Index()
        {
            return View();
        }
        //Customer/Device SearchView
        string Baseurl = "http://localhost:51065";
        public async Task<ActionResult> DataMenu(string accessToken)
        {
            List<Models.Customer> data = new List<Models.Customer>();
            
            using (var client = new HttpClient())
            {
                //Passing service base url  
                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();
                //Define request data format  
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Add("Accept", "application/*+xml;version=5.1");
                client.DefaultRequestHeaders.Add("Authorization", "Bearer " + accessToken);
                //Sending request to find web api REST service resource GetAllCustomers using HttpClient  
                HttpResponseMessage Res = await client.GetAsync("/api/CutomerData");

                //Checking the response is successful or not which is sent using HttpClient  
                if (Res.IsSuccessStatusCode)
                {
                    //Storing the response details recieved from web api   
                    var dataResponse = Res.Content.ReadAsStringAsync().Result;

                    //Deserializing the response recieved from web api and storing into the Employee list  
                    data = JsonConvert.DeserializeObject<List<Models.Customer>>(dataResponse);
                }
                //returning the employee list to view  
                return View(data);
            }
        }
        //DiagnosticDataView
        public async Task<ActionResult> DataLog(string accessToken, string customer, string device, string days, string date_to)
        {
            List<Log> data_log = new List<Log>();
            if (User.Identity.IsAuthenticated)
            {
                ViewBag.customer = customer;
                ViewBag.device = device;
                ViewBag.perriode = $"{DateTime.Now.Date.AddDays(- int.Parse(days)).ToShortDateString()} - {DateTime.Now.Date.ToShortDateString()}";
            }
            using (var client = new HttpClient())
            {
                //Passing service base url  
                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();
                //Define request data format  
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Add("Accept", "application/*+xml;version=5.1");
                client.DefaultRequestHeaders.Add("Authorization", "Bearer " + accessToken);
                //Sending request to find web api REST service resource GetAllEmployees using HttpClient  
                HttpResponseMessage Res = await client.GetAsync("/api/DiagnosticData?" +
                    $"customer={HttpUtility.UrlEncode(customer)}" +
                    $"&device={HttpUtility.UrlEncode(device)}" +
                    $"&days={HttpUtility.UrlEncode(days)}" +
                    $"&date_to={HttpUtility.UrlEncode(date_to)}");

                //Checking the response is successful or not which is sent using HttpClient  
                if (Res.IsSuccessStatusCode)
                {
                    //Storing the response details recieved from web api   
                    var dataResponse = Res.Content.ReadAsStringAsync().Result;

                    //Deserializing the response recieved from web api and storing into the Employee list  
                    data_log = JsonConvert.DeserializeObject<List<Log>> (dataResponse);
                }
                if (data_log.Count == 0)
                {
                    HttpResponseMessage Res001 = await client.GetAsync("/api/DiagnosticData/getkey/" + HttpUtility.UrlEncode(device));

                    if (Res001.IsSuccessStatusCode)
                    {
                        
                        var dataResponse = Res001.Content.ReadAsStringAsync().Result;
                        ViewBag.productKey = dataResponse;
                    }
                    var d = Res001.StatusCode;
                }
                //returning the employee list to view  
                return View(data_log);
            }
        }
        //provide functionality to log user of the system
        public ActionResult LogOut()
        {
            if (System.Web.HttpContext.Current != null)
            {
                int cookieCount = System.Web.HttpContext.Current.Request.Cookies.Count;
                for (var i = 0; i < cookieCount; i++)
                {
                    var cookie = System.Web.HttpContext.Current.Request.Cookies[i];
                    if (cookie != null)
                    {
                        var expiredCookie = new HttpCookie(cookie.Name)
                        {
                            Expires = DateTime.Now.AddDays(-1),
                            Domain = cookie.Domain
                        };
                        System.Web.HttpContext.Current.Response.Cookies.Add(expiredCookie); // overwrite it
                    }
                }

                // clear cookies server side
                System.Web.HttpContext.Current.Request.Cookies.Clear();
            }
            // redirect to main page after logout
            return RedirectToAction("Index");
        }
    }
}
