﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace diagnostic_tool_web_api.Models
{
    public class Log
    {
        public int Fk_sensor_id { get; set; }
        public string Sensor_name { get; set; }
        public string Product_key { get; set; }
        public DateTime Log_timestamp { get; set; }
        public string Log_value { get; set; }
    }
}