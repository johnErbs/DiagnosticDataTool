﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace diagnostic_tool_web_api.Models
{
    public class PlayerDevice
    {
        public int PD_id { get; set; }
        public string PD_name { get; set; }
        public string ProductKey { get; set; }
    }
}