﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Web;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;


namespace diagnostic_tool_web_api.Security.AuthModels
{
    public class BasicAuthentificationAttribute : AuthorizationFilterAttribute
    {
        public override void OnAuthorization(HttpActionContext actionContext)
        {
            //base.OnAuthorization(actionContext);
            if (actionContext.Request.Headers.Authorization == null)
            {
                actionContext.Response = actionContext.Request.CreateResponse(HttpStatusCode.Unauthorized);
            }
            else
            {
                //authentificationToken is base 64encoded
                string authToken = actionContext.Request.Headers.Authorization.Parameter;
                authToken = Base64Encode(authToken);
                //string decodedAutToken = Encoding.UTF8.GetString(Convert.FromBase64String(authentificationToken));
                //string productKey = decodedAutToken;
                if (PlayerDeviceSecurity.AllowPost(authToken))
                {
                    Thread.CurrentPrincipal = new GenericPrincipal(new GenericIdentity(authToken), null);
                }
                else
                {
                    actionContext.Response = actionContext.Request.CreateResponse(HttpStatusCode.Unauthorized);
                }
            }
        }
        public static string Base64Encode(string authToken)
        {
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(authToken);
            return System.Convert.ToBase64String(plainTextBytes);
        }
    }
}