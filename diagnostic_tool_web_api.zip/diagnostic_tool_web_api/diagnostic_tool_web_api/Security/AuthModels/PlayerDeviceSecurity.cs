﻿using diagnostic_tool_web_api.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using data_access.data_access_layer;

namespace diagnostic_tool_web_api.Security.AuthModels
{
    internal class PlayerDevice
    {
        internal static string ProductKey { get; set; }
    }

    public class PlayerDeviceSecurity
    {
        public static bool AllowPost(string productKey)
        {
            //PlayerDevice playerDevice = new PlayerDevice();
            PlayerDevice.ProductKey = productKey;
            productKey = DataContextLayer.ReadDataDeviceKey(productKey);
            return (PlayerDevice.ProductKey == productKey);
        }

        internal static string encrypt(string productKey)
        {
            return productKey = sha256(productKey);
        }

        protected static string sha256(string productKey)
        {
            var crypt = new System.Security.Cryptography.SHA256Managed();
            var hash = new System.Text.StringBuilder();
            byte[] crypto = crypt.ComputeHash(Encoding.UTF8.GetBytes(productKey));
            foreach (byte theByte in crypto)
            {
                hash.Append(theByte.ToString("x2"));
            }
            return hash.ToString();
        }
    }
}