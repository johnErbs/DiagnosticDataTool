﻿// random colors for the chart
function random_rgba() {
    var o = Math.round, r = Math.random, s = 255;
    return 'rgba(' + o(r() * s) + ',' + o(r() * s) + ',' + o(r() * s) + ',' + r().toFixed(1) + ')';
}

function get_details_data(chart_type) {
    if ($('#div_chart').hasClass('hidden')) {
        $('#div_chart').removeClass('hidden');
    }
    // - canvas gui_builder
    let ctx;
    if (chart_type === 'line') {
        $('#chart001').remove();
        $('#div_chart').append('<canvas id="chart001" style="width:100%; height:500px"></canvas>');
        ctx = document.getElementById("chart001").getContext('2d');
        $('#chart001').show();
        $('#chart002').hide();
        $('#chart003').hide();
    }
    if (chart_type === 'radar') {
        $('#chart002').remove();
        $('#div_chart').append('<canvas id="chart002" style="width:100%; height:500px"></canvas>');
        ctx = document.getElementById("chart002").getContext('2d');
        $('#chart001').hide();
        $('#chart002').show();
        $('#chart003').hide();
    }
    if (chart_type === 'bar') {
        $('#chart003').remove();
        $('#div_chart').append('<canvas id="chart003" style="width:100%; height:500px"></canvas>');
        ctx = document.getElementById("chart003").getContext('2d');
        $('#chart001').hide();
        $('#chart002').hide();
        $('#chart003').show();
    }

    //Varibales for detailed sensor view
    // - chart data
    let data
    // - Sensor label
    let sensor_id = "";
    let sensor_type = "";
    // - labels along x-axis
    let date = [];
    let time = [];
    // concat date + time variables
    let date_time = [];
    // - data for drawing the line
    let sensor_values = [];
    let cpu_values = { core_001: [], core_002: [] };
    // chart line colors
    let colors = [];
    // - chart
    let chart;
    

    $('#table_detail > tbody  > tr').each(function () {
        sensor_id = this.cells[0].innerHTML;
        sensor_type = this.cells[1].innerHTML;
        date.push(this.cells[2].innerHTML);
        time.push(this.cells[3].innerHTML);
        var data_value = this.cells[4].innerHTML;
        if (data_value.includes('#')) {
            var arr_val = data_value.split('#');
            var core_001 = arr_val[1];
            var core_002 = arr_val[2];
            var core_001_res = core_001.substring(2, 5);
            var core_002_res = core_002.substring(2, 5);
            cpu_values.core_001.push(core_001_res);
            cpu_values.core_002.push(core_002_res);
        } else {
            sensor_values.push(data_value);
        }
    });

    for (var i = 0; i < parseInt(date.length); i++) {
        date_time.push(date[i] + ' ' + time[i]);
        var color = random_rgba();
        colors.push(color);
    }
    if (parseInt(cpu_values.core_001.length) === 0) {
        var label_name = sensor_type;
        if (label_name === 'bandwithsensor')
            label_name = sensor_type + ' kb/s';
        if (label_name === 'statussensor')
            label_name = sensor_type + ' (1: aktiv, 0: in-aktiv)';

        data = {
            labels: date_time,
            datasets: [{
                label: label_name,
                data: sensor_values,
                backgroundColor: colors,
                borderColor: [
                    'rgba(17, 1, 80, 0.93)',
                ],
                borderWidth: 1,
            }]
        };
    } else {
        data = {
            labels: date_time,
            datasets: [
                {
                label: 'CPU core #1',
                data: cpu_values.core_001,
                backgroundColor: colors,
                borderColor: [
                    'rgba(17, 1, 80, 0.93)',
                ],
                borderWidth: 1,
                },
                {
                    label: 'CPU core #2',
                    data: cpu_values.core_002,
                    backgroundColor: colors,
                    borderColor: [
                        'rgba(17, 1, 80, 0.93)',
                    ],
                    borderWidth: 1,
                }
            ]
        };
    }
    var options = {
        maintainAspectRatio: false,
        elements: {
            line: {
                tension: 0, // disables bezier curves
            }
        },
        scales: {
            yAxes: [{
                ticks: {
                    min: 0,
                    beginAtZero: true,
                },
                gridLines: {
                    display: true,
                    color: "rgba(255,99,164,0.2)"
                }
            }],
            xAxes: [{
                ticks: {
                    min: 0,
                    beginAtZero: true,
                    maxRotation: 0 // angle in degrees
                },
                gridLines: {
                    display: false
                }
            }],
            
        }
    };

    chart = new Chart(ctx, {
        options: options,
        data: data,
        type: chart_type
    });
};